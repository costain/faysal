
=> Compilation and execution instruction for each file is given inside the comment section at the end of the file

=> Problem 2 use a 1D partitioning scheme to divide the workload among processes

=> Following are the execution time of bfs for Email-enron (enron.csr) graph with different number of processes for problem 2

NumPr		Runtime(sec)
1		15.40
2		7.74
4		4.04
8		2.28
16		1.87
32		1.92
64		2.17


=> Working on problem 3, will upload the code once done