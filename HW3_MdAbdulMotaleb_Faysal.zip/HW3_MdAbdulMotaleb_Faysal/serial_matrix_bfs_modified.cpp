#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>

using namespace std;


int main(int argc, char* argv[])
{
	if(argc<2)
	{
		cout<<"usage: program inputfile"<<endl;
		return 0;
	}
	
	bool** A;
	bool* frontier;
	bool* update;
	int* distance;
	bool frontier_empty = true;
	vector<int> index_list;
	
	int vertices = 0;
	int line_counter = 0;
	
	char* token;
	
	FILE* fp = fopen(argv[1], "r");
	
	
	if(fp==NULL)
	{
		exit(EXIT_FAILURE);
	}
	
	cout<<"File open successful\n";
	
	char* line = NULL;
	
	size_t len = 0;
	
	if((getline(&line, &len, fp)!= -1))
	{
		token = strtok(line," \n\t");
		
		if(token!= NULL)
		{
			vertices = atoi(token);
			printf("number of vertices:%s\n", token);
		}
		
		frontier = (bool*)malloc(vertices*sizeof(bool));
		update = (bool*)malloc(vertices*sizeof(bool));
		distance = (int*)malloc(vertices*sizeof(int));
		
		A = (bool**)malloc(vertices*sizeof(bool*));
		
		for(int i=0 ;i<vertices; i++)
		{
			A[i] = (bool*) malloc(vertices*sizeof(bool));
			memset(A[i], false, vertices);
			distance[i] = -999999;
			frontier[i] = false;
			update[i] = false;
		}
	}
	
	while((getline(&line, &len, fp)!= -1))
	{	
		if(strlen(line) <= 2)
		{
			break;
		}
		token = strtok(line," \n\t");
		
		while(token != NULL){
			long edge = atoi(token);
			A[line_counter][edge] = 1;
			token = strtok(NULL," \n\t");
		}
		line_counter++;
	}
	
	//initialize the source vertex 
	
	frontier[0] = true;
	frontier_empty = false;
	distance[0] = 0;
	int level = 0;
	index_list.push_back(0);
	
	//start execution
	
	while(!frontier_empty)
	{
		for(int i=0; i<vertices; i++)  //starts in column i of the matrix A
		{
			for(int j=0; j<index_list.size(); j++)
			{
				int index = index_list[j];
				if(frontier[index]==true && A[index][i]==true)
				{
					update[i] = true;
				}
			}
		}
		
		for(int i=0; i<index_list.size(); i++)
		{
			int index= index_list[i];
			frontier[index] = false;
		}
		
		vector<int>().swap(index_list);
		
		frontier_empty = true;
		
		
		//now update the distance vector
		
		for(int i=0; i<vertices; i++)
		{
			if(update[i]==true && distance[i]==-999999)
			{
				distance[i] = level+1;
				frontier[i] = true;
				index_list.push_back(i);
				frontier_empty = false;
			}
		}
		
		level++;
	}
	
	//printf bfs
	
	for(int i=0; i<vertices; i++)
	{
		printf("vertex:%d, distance[%d]:%d\n", i, i, distance[i]);
	}
	
	//clean up memory
	fclose(fp);
	if(line)
	{
		free(line);
	}
	for(int i=0;i<vertices; i++)
	{
		free(A[i]);
	}
	free(A);
	free(frontier);
	free(update);
	free(distance);
	
 return 0;	
}



/* execution instruction

To compile

g++ serial_matrix_bfs_modified.cpp -o serial_bfs

To execute

./serial_bfs sample_graph			---> (here sample_graph is one of the attached csr file)


*/





