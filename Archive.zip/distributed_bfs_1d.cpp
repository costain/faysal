#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<mpi.h>
#include<stdbool.h>


using namespace std;


void findAssignedPart(int* start, int* end, int numNodes, int numPr, int myID) {
	if (numNodes % numPr == 0) {
		*start = (numNodes / numPr) * myID;
		*end = (numNodes / numPr) * (myID + 1);
	} else {
		int block = numNodes / numPr;
		int modular = numNodes % numPr;

		if (myID < modular) {
			*start = (block + 1) * myID;
			*end = (block + 1) * (myID + 1);
		} else {
			*start = block * myID + modular;
			*end = block * (myID + 1) + modular;
		}
	}
}


int main(int argc, char* argv[])
{

	MPI_Init(NULL, NULL);
	
	if(argc<2)
	{
		cout<<"usage: program inputfile"<<endl;
		return 0;
	}
	
	
	int rank,size;
	
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	
	int* counts = (int*)malloc(size*sizeof(int));
	int* displs = (int*)malloc(size*sizeof(int));
	
	int* index_sizes = (int*)malloc(size*sizeof(int));
	int* index_displs = (int*)malloc(size*sizeof(int));
	
	bool** A;
	bool* frontier;
	bool* sendBuffer;
	bool* update;
	int* distance;
	int total_frontier = 0;	
	int* localIndices;
	int* globalIndices;
	
	int vertices = 0;
	int line_counter = 0;
	int start, end;
	
	char* token;
	
	FILE* fp = fopen(argv[1], "r");
	
	
	if(fp==NULL)
	{
		exit(EXIT_FAILURE);
	}
	
	
	char* line = NULL;
	
	size_t len = 0;
	
	if((getline(&line, &len, fp)!= -1))
	{
		token = strtok(line," \n\t");
		
		if(token!= NULL)
		{
			vertices = atoi(token);
			//printf("number of vertices:%s\n", token);
		}
		
		frontier = (bool*)malloc(vertices*sizeof(bool));
		
		findAssignedPart(&start, &end, vertices, size, rank);
		
		int chunk = end-start;
		
		localIndices = (int*)malloc(chunk*sizeof(int));
		
		globalIndices = (int*)malloc(vertices*sizeof(int));
		
		sendBuffer = (bool*) malloc(chunk*sizeof(bool));
		
		memset(sendBuffer, false, chunk);	//initializing sendBuffer with false 
		
		update = (bool*)malloc(vertices*sizeof(bool));
		
		distance = (int*)malloc(vertices*sizeof(int));
		
		A = (bool**)malloc(vertices*sizeof(bool*));
		
		for(int i=0 ;i<vertices; i++)
		{
			A[i] = (bool*) malloc(vertices*sizeof(bool));
			memset(A[i], false, vertices);
			distance[i] = -999999;
			frontier[i] = false;
			update[i] = false;
		}
	}
	

	//now compute the size of the chunk of frontier each process is going to send
	int startIndex, endIndex;
	
	double startTime = MPI_Wtime();
	
	for(int i =0; i<size; i++)
	{
		findAssignedPart(&startIndex, &endIndex, vertices, size, i);
		counts[i] = endIndex - startIndex;
		
	}
	
	displs[0] = 0;
	
	for(int i= 1; i<size; i++)
	{
		displs[i] = displs[i-1] + counts[i-1];
	}
	
	//now read the rest of the file written in CSR format and load in boolean matrix A
	
	while((getline(&line, &len, fp)!= -1))
	{	
		if(strlen(line) <= 2)
		{
			break;
		}
		token = strtok(line," \n\t");
		
		while(token != NULL){
			long edge = atoi(token);
			A[line_counter][edge] = true;
			token = strtok(NULL," \n\t");
		}
		line_counter++;
	}
	
	//initialize the source vertex 
	
	frontier[0] = true;
	distance[0] = 0;
	int level = 0;
	globalIndices[0] = 0;
	total_frontier = 1;
	
	//start execution
	
	while(total_frontier > 0)
	{
		for(int i = start; i<end; i++)  //starts in column i of the matrix A
		{
			for(int j=0; j<total_frontier; j++)
			{
				int index = globalIndices[j];
				
				if(frontier[index] == true && A[index][i] == true)
				{
					update[i] = true;
				}				
			}
		}
		
		
		// here reinitialize the frontier
	
		total_frontier = 0;
		
		
		
		//now update the distance vector
		
		int send_Index = 0;
		int lsize = 0;
		
		for(int i=start; i<end; i++)
		{
			if(update[i] == true && distance[i] == -999999)
			{
				distance[i] = level+1;
				sendBuffer[send_Index] = true;
				localIndices[lsize] = i;
				lsize++;
			}
			else
			{
				sendBuffer[send_Index] = false;
			}
			send_Index++;
		}
		
		//gathering the distance vector in all of the processes so that each process has an updated distance result from all local updates across processors
		MPI_Allgatherv(MPI_IN_PLACE, 0, MPI_DATATYPE_NULL, distance, counts, displs, MPI_INT, MPI_COMM_WORLD);
		
		// receive the information from all process about how many local_indices data each process has		
		MPI_Allgather(&lsize, 1, MPI_INT, index_sizes, 1, MPI_INT, MPI_COMM_WORLD);
		
		index_displs[0] = 0;
		
		for(int i=1; i<size; i++)
		{
			index_displs[i] = index_displs[i-1]+ index_sizes[i-1];
			total_frontier += index_sizes[i-1];
		}
		
		total_frontier+= index_sizes[size-1];
				
		MPI_Allgatherv(localIndices, index_sizes[rank], MPI_INT, globalIndices, index_sizes, index_displs, MPI_INT, MPI_COMM_WORLD);
			
		MPI_Allgatherv(sendBuffer, counts[rank], MPI_C_BOOL, frontier, counts, displs, MPI_C_BOOL, MPI_COMM_WORLD);
		
		level++;
	}
	
	double endTime = MPI_Wtime();
	
	
	printf("time taken for finishing bfs computation:%f seconds\n", endTime - startTime);
	//printf bfs
/*
	for(int i=0; i<vertices; i++)
	{
		printf("rank:%d, vertex:%d, distance[%d]:%d\n", rank, i, i, distance[i]);
	}
*/
	//clean up memory
	

	fclose(fp);
	if(line)
	{
		free(line);
	}
	for(int i=0;i<vertices; i++)
	{
		free(A[i]);
	}
	free(A);

	free(counts);
	free(displs);
	free(index_sizes);
	free(index_displs);
	free(frontier);
	free(sendBuffer);
	free(update);
	free(distance);
	free(localIndices);
	free(globalIndices);

		
	MPI_Finalize();
	
 return 0;
 	
}


/*

To compile

mpic++ distributed_bfs_1d.cpp -o distbfs

to run

mpirun -n numProc ./distbfs your_graph_file.csr

*/



